package gb.demo.Office;

import org.springframework.stereotype.Component;

@Component
public class Worker {
}
